# Datei: pynbTurtle/__init__.py

from .turtle import Turtle